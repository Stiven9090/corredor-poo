EXPOSICIÓN SOLID

                       SEGUNDA FORMA NORMAL 

FCICHA: 3145555
Kevin Stiven Lopez AMAYA 
El software debe estar ABIERTO a extensión pero CERRADO a modificación.
- Puedes agregar nuevas funcionalidades
- Sin tener que modificar el código ya existente que funciona
* LO QUE NOS AYUDAS A RESOLVER 
Nos ayuda a que  cada vez que necesites una nueva función
reescribamos código
tocar clases que ya estaban probadas
romper algo que funcionaba bien


El enchufe de la pared 
La pared tiene un enchufe (esa es la interfaz o punto común).

Los electrodomésticos (licuadora, tele, cargador) son extensiones que se conectan al enchufe.

Cuando compras un nuevo electrodoméstico no tocas la pared ni cambias el enchufe.

Solo conectas el nuevo aparato.

Resultado: la pared quedó “cerrada” (no la modificas) pero abierta a extensión (puedes conectar aparatos nuevos).

codigo incorrecto 
 * class Reporte {
    void generar(String tipo) {
        if (tipo.equals("PDF")) System.out.println("PDF");
        if (tipo.equals("WORD")) System.out.println("Word");
    }
}

por que el codigo es incorrecto 

Hay una sola clase Reporte que contiene toda la lógica.

Para agregar un nuevo formato ( EXCEL) debemos abrir y modificar Reporte.

Cada modificación arriesga romper lo que ya funciona (más bugs, más pruebas).

Esto no es Open/Closed: el código no está cerrado a cambios.

codigo correcto 

* abstract class Reporte {
    abstract void generar();
}

class ReportePDF extends Reporte {
    @Override
    void generar() { System.out.println("Generando PDF"); }
}

class ReporteWord extends Reporte {
    @Override
    void generar() { System.out.println("Generando Word"); }
}

Reporte es la interfaz

ReportePDF y ReporteWord son aplicaciones que cumplen ese contrato como los electrodomésticos.

No modificas Reporte al añadir uno nuevo, creas una nueva clase que extiende Reporte

El resto del sistema puede usar Reporte sin saber los detalles concretos polimorfismo.

* Métodos de pago (PagoTarjeta, PagoEfectivo)

abstract class Pago {
    abstract void procesar(double monto);
}

class PagoTarjeta extends Pago {
    @Override
    void procesar(double monto) {
        System.out.println("Procesando pago con tarjeta: " + monto);
    }
}

class PagoEfectivo extends Pago {
    @Override
    void procesar(double monto) {
        System.out.println("Procesando pago en efectivo: " + monto);
    }
}

class Procesador {
    void ejecutarPago(Pago pago, double monto) {
        pago.procesar(monto);
    }
}

Pago es la abstracción (contrato), como el enchufe.

Cada forma concreta (tarjeta, efectivo) implementa Pago.

Para añadir PagoCripto sólo creas class PagoCripto extends Pago — no modificas las clases existentes.

Procesador usa la abstracción Pago y no se preocupa por implementaciones concretas → extensión sin modificación: OCP cumplido.


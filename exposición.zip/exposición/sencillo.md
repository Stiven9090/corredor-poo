1 ejemplo 
Padre → Pez 
Todos los peces nadan 

Subclase → Tiburón 
Nadar--> nada 
si Puede heredar

Subclase → PezDeJuguete que no se mueve 
No debería heredar de Pez
Porque rompe la regla principal: nadar

Si la hija no cumple la regla básica del padre, entonces esa herencia está mal diseñada.



El cajero dice:

“Aquí todos los métodos de pago deben procesar el dinero”

 Entonces pasan:

PagoTarjeta
Cobra sin problema 
"Pago con tarjeta"

PagoEfectivo
Cobra sin problema S
"Pago en efectivo"

Todo funciona, nadie se confunde, nadie rompe reglas 

Cumple el principio
Todo el sistema es confiable y estable
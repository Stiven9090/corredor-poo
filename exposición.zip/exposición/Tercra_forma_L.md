EXPOSICIÓN SOLID

                       TERCERA FORMA NORMAL 

FCICHA: 3145555
Kevin Stiven Lopez AMAYA 


![alt text](image.png)

Una hija debe poder reemplazar a su padre sin dañar el programa;
la clase hija debe poder hacer todo lo que la clase padre puede hacer
Es lo que nos dice con la frase 
Cuando creamos una clase hija (subclase), esta debe:


-Hacer lo mismo que hace la clase padre
-Cumplir con las mismas reglas
-No provocar errores inesperados

--> Qué busca este principio?

Herencias bien utilizadas
Que no se rompa el polimorfismo
Que una subclase cumpla las reglas del padre

Si al usar una hija en lugar del padre el programa se rompe → violaste LSP

# Manera sencilla de comprenderlo es de la manera que  Si la hija no puede comportarse como el papá no deberia ser su hija.

# 1) un ejemplo sencillo de la vida es si un carro es un vehiculo, por simple logica debe poder moverse.,

Clase padre:

Vehículo ➝ Se espera que se mueva 

Subclases--> posibles:

Carro --> se mueve

Moto --> se mueve

Bicicleta --> se mueve

carroporcelana 
este NO se mueve
rompe lo que se espera de un vehículo

# Violamos el  LSP
Porque cuando alguien usa un vehículo en el programa, asumirá que se puede mover.

un ejemplo seria 
# void iniciar(Vehiculo v) {
   # v.acelerar(); // Se espera que esto siempre funcione
# }
si esta funcion es enviada para un carro,moto., es valida por que esta cumpliendo con lo acordado que es que el  carro acelera.

al contrario que si enviamos un carroporcelana 
# El programador confía en que “vehículo acelera” siempre es verdad,pero la subclase le dañó ese contrato.

 2) ave y pinguino 
# class Ave {
# void volar() { System.out.println("Volando"); }
# }

# class Pinguino extends Ave {
# void volar() { throw new UnsupportedOperationException(); }
# }


# 2) Ave y Pingüino — explicado 
# class Ave {
# void volar() { System.out.println("Volando"); }
# }

--> toda ave sabe volar, según el código.Es su regla principal

hacemos una subclase
# class Pinguino extends Ave {
# void volar() { throw new UnsupportedOperationException(); }
# }

El pingüino no puede volar en la vida real 
Entonces, cuando alguien lo obliga a volar en el programa 

nos arroja un  error → rompiendo el sistema

# Dónde está el problema
“Si es un ave, puede volar”

Pero el pingüino dice “Yo soy un ave  ¡pero no vuelo!”

solucion seria 

interface Voladora {
    void volar();
}

class Ave { }

class Golondrina extends Ave implements Voladora {
    public void volar() { System.out.println("Volando"); }
}

class Pinguino extends Ave {
    // No tiene volar() porque no puede 
}

ya no obligaremos a un pingüino a volar
Se evita el error inesperado
Se respeta el LSP 


3) # Métodos de pago explicado paso a paso

# abstract class Pago {
# abstract void procesar(double monto);
# }

Todo tipo de pago debe procesar dinero
Es una regla fundamental de la clase padre
Ningún pago puede existir sin procesar un monto

Ahora creamos dos hijos
class PagoTarjeta extends Pago {
    void procesar(double monto) { System.out.println("Pago con tarjeta"); }
}

class PagoEfectivo extends Pago {
    void procesar(double monto) { System.out.println("Pago en efectivo"); }
}
Que hicimos 
| Clase hija   | ¿Puede procesar un pago? | ¿Cumple la regla del padre? |
| ------------ | :----------------------: | :-------------------------: |
| PagoTarjeta  |            Sí           |             Sí            |
| PagoEfectivo |            Sí           |             Sí            |


La manera en como funciona
Pago p1 = new PagoTarjeta();
Pago p2 = new PagoEfectivo();

p1.procesar(100);
p2.procesar(50);

Funciona perfectamente
No hay errores
Ninguna subclase rompe las reglas

Cumple con  LSP 

4) # Documento editable vs PDF protegido (VIOLA LSP)
Regla del “padre”
clase padre llamada Documento con una regla simple
si tenes algo que es un Documento, el programa espera poder modificar su contenido

Subclases
DocumentoWord → editable 
PDFProtegido → no editable (tiene bloqueo, contraseña o permisos) 

Que pasa en la practica 
# void abrirYEditar(Documento d) {
# d.editar("nuevo texto");
# }

Si d es DocumentoWord → funciona OK.
Si d es PDFProtegido → editar() falla porque el PDF no permite editar.
# Porque el contrato del padre (que todo Documento se puede editar) no se cumple para PDFProtegido

Cómo arreglarlo
Opción 1— Separar responsabilidades
Crear una interfaz Editable.
Sólo las clases que realmente permiten edición implementan Editable.

interface Editable { void editar(String texto); }
class Documento { }
class DocumentoWord extends Documento implements Editable {  }
class PDFProtegido extends Documento {  }






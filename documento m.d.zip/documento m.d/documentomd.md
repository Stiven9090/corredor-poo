DOCUMENTO 
#  PRIMER PASO 
Es montar cada motor de base  en docker como mysql mongo etc., para esto utlizariamos los siguientes comandos,

![alt text](image.png)

luego de ejercutar el comando en su interfac de docker te pareseria algo asi o  similar a claro que seria en la parte de iamgenes 
![alt text](image-2.png)
desde terminal se tendria que mirar asi.
![alt text](image-4.png)

y como ultimo en la parte de los container te pareceria asi
![alt text](image-3.png)

# SEGUNDO PASO 
Es montar cada motor de base con su contenedor con los siguiente comando 
![alt text](image-1.png)

# TERCER PASO 
Es conectar la base de datos 
con los siguientes comandos 
conectar desde terminal dentro del contenedor 
![alt text](image-5.png)

1234 → contraseña
Una vez dentro, podrás ejecutar comandos como:

 use mi_base
db.createCollection("usuarios")
En pocas palabras:

mi_base es el nombre que le das a tu base de datos inicial dentro del contenedor de MongoDB.

Puedes cambiarlo a cualquier otro nombre que necesites para tu proyecto.

# CREAMOS EL UBUNTU 
Descargar la imagen de Ubuntu
docker pull ubuntu:22.04
Crear y ejecutar el contenedor
docker run -it --name mi_ubuntu ubuntu:22.04 /bin/bash

FUNCION DE CADA UNO -it → modo interactivo con terminal.

--name mi_ubuntu → nombre que le das al contenedor.

ubuntu:22.04 → imagen que estás usando.

/bin/bash → abre la terminal dentro del contenedor.
# (Opcional) Instalar SQL Server y sqlcmd dentro del contenedor

# Instalar dependencias
apt install -y curl apt-transport-https gnupg

# Importar llave de Microsoft y agregar repositorio
curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -
curl https://packages.microsoft.com/config/ubuntu/22.04/mssql-server-2022.list > /etc/apt/sources.list.d/mssql-server.list
apt update
Instalar SQL Server
apt install -y mssql-server

# Configurar SQL Server (te pedirá la contraseña de 'sa')
/opt/mssql/bin/mssql-conf setup

# Instalar sqlcmd
apt install -y mssql-tools unixodbc-dev
echo 'export PATH="$PATH:/opt/mssql-tools/bin"' >> ~/.bashrc
source ~/.bashrc

# Iniciar SQL Server
/opt/mssql/bin/sqlservr &

# CUARTO PASO 
# Obtener la IP o puerto de tu contenedor

verificamos si el contenedor esta corriendo  con el siguiente comando.
docker ps

veremos una interfac asi    

![alt text](image-6.png)

Asegúrate de que el puerto 1433 esté mapeado al host (0.0.0.0:1433->1433/tcp).
si no lo hicimos al INICIAR TOCA HACERLO  CREAR EL CONTENEDOR.
Con este comando lo podras hacer 

docker run -e 'ACCEPT_EULA=Y' -e 'SA_PASSWORD=TuContraseña' -p 1433:1433 -d --name mi_ubuntu ubuntu:22.04

# Conexión desde SSMS

1.Abre SQL Server Management Studio.

2.En Server name

se coloca la  IP DEL DISPOSITIVO, Y EL PUERDO DEL CONTENEDOR 
127.0.0.1,1433
# ejemplo breve 
127.0.0.1 → localhost (tu máquina).

,1433 → puerto mapeado del contenedor.

Authentication: SQL Server Authentication

Login: sa

Password: tu contraseña de sa

# Conexión a varios servidores (register servers)

En SSMS puedes usar Registered Servers:

Ve a View → Registered Servers.

Click derecho → New Server Registration.

Pon los detalles del contenedor (IP, puerto, login y contraseña).

Repite para cada contenedor o servidor que quieras administrar.

Esto no elimina ningún servidor existente, solo los registra para acceso rápido.

Puedes organizar varios servidores en carpetas sin riesgo.

